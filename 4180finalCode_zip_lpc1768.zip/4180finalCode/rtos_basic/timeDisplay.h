#include "mbed.h"
#include <string>
class timeDisplay
{
    public:
        void setTime();
        string displayTime();
};
