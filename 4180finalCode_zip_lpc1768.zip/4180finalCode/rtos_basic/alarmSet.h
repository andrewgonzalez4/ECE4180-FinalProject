#include "mbed.h"
#include <string>
class alarmSet
{
    public:
        string alarmDisplay();
        void hourSet();
        void minuteSet();
};
