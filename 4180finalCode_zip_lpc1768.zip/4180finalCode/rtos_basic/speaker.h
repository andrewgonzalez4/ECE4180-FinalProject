#include "mbed.h"
class speaker
{
    public:
        void speakerInit();
        void turnOffSpeaker();
};
